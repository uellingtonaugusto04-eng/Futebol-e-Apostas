# 📱 GUIA ANDROID — Painel de Estatísticas das 8 Ligas

O app é uma página web moderna (HTML). No Android ele pode ser usado de 3 formas:

────────────────────────────────────────────────────────────
## ✅ OPÇÃO 1 — Hospedar grátis no GitHub (RECOMENDADA)
App aberto pelo navegador do celular, dados atualizados TODO DIA
automaticamente, sem precisar de PC ligado. Funciona offline após
o primeiro acesso (PWA instalável).

1. Crie uma conta em https://github.com
2. Crie um repositório PÚBLICO chamado, por exemplo, `stats-ligas`
3. Envie para o repositório estes arquivos:
     app.html, manifest.json, sw.js, seed_app.json,
     update_from_sofascore.py, icons/ (pasta com os 2 ícones),
     .github/workflows/atualizar-dados.yml
4. (Opcional, recomendado) renomeie `app.html` → `index.html`
   e no arquivo `sw.js` troque `app.html` por `index.html`
5. Ative o GitHub Pages: Settings → Pages → Source: branch `main`,
   pasta `/ (root)` → Save. Em 1-2 minutos o app fica no ar em:
     https://SEU-USUARIO.github.io/stats-ligas/
6. CARGA INICIAL (dados até hoje): no seu computador rode
   uma vez:  python update_from_sofascore.py --desde 2026-08-01
   e envie os arquivos `dados_sofascore.js` e `sofascore_state.json`
   gerados para o repositório. (Se não tiver PC, pule — o app
   começa a acumular da primeira execução diária.)
7. Pronto: o workflow roda todo dia às 08h e já faz commit dos dados.

### Instalar como APP na tela inicial do Android:
   1. Abra a URL do app no Chrome
   2. Menu (⋮) → "Adicionar à tela inicial" / "Instalar app"
   3. Pronto — vira um app com ícone próprio, tela cheia, offline.

────────────────────────────────────────────────────────────
## ✅ OPÇÃO 2 — Tudo dentro do celular (Termux)
Sem PC e sem GitHub. O próprio celular busca os dados do SofaScore.

1. Instale o Termux (F-Droid): https://f-droid.org/packages/com.termux/
2. No Termux:
     pkg update && pkg install python -y
     cd /sdcard/Download/stats     (crie a pasta e copie os arquivos)
     python update_from_sofascore.py --desde 2026-08-01   (carga inicial)
3. Para rodar TODO DIA automaticamente, instale o Termux:API
   (F-Droid) e adicione ao crontab do Termux:
     pkg install cronie termux-api -y
     crontab -e  →  linha:  0 8 * * * cd /sdcard/Download/stats && python update_from_sofascore.py >> log.txt 2>&1
4. Abra o app.html com qualquer navegador (Chrome) — na pasta
   Download/stats, tocando no arquivo.

────────────────────────────────────────────────────────────
## ✅ OPÇÃO 3 — PC atualiza, celular só visualiza
Se você já usa o script no PC, sincronize a pasta do app com o
celular via Syncthing (grátis, Play Store/F-Droid) ou Google Drive.
O app.html lê o `dados_sofascore.js` atualizado automaticamente.

────────────────────────────────────────────────────────────
## 📋 Resumo

| Opção | Precisa de | Atualização | Instalável (PWA) |
|-------|-----------|-------------|------------------|
| 1. GitHub | só celular + 1ª config. | automática todo dia 08h | sim |
| 2. Termux | celular (com Termux) | automática (cron no celular) | sim (via arquivo) |
| 3. PC + sync | PC ligado na hora | manual/no PC | sim (via arquivo) |

Dúvidas sobre qual combina mais com você? Me diga o que prefere
que eu detalho o passo a passo.
