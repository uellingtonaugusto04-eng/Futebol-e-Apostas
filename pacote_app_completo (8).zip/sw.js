const CACHE = 'painel8ligas-v1';
const ARQS = ['./', './app.html', './manifest.json', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARQS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => { e.waitUntil(clients.claim()); });
self.addEventListener('fetch', e => {
  const url = e.request.url;
  // dados do SofaScore: rede primeiro (sempre fresco), cache como reserva
  if (url.indexOf('dados_sofascore') !== -1) {
    e.respondWith(fetch(e.request).then(r => {
      const copia = r.clone();
      caches.open(CACHE).then(c => c.put(e.request, copia));
      return r;
    }).catch(() => caches.match(e.request)));
    return;
  }
  // restante do app: cache primeiro (funciona offline)
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(resp => {
    const copia = resp.clone();
    caches.open(CACHE).then(c => c.put(e.request, copia));
    return resp;
  }).catch(() => caches.match('./app.html'))));
});
