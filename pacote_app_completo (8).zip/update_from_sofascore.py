#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
update_from_sofascore.py
========================
Alimenta o app.html com estatísticas oficiais de partidas finalizadas,
coletadas da API não-oficial do SofaScore (api.sofascore.com).

USO
---
  python update_from_sofascore.py                  # ontem, todas as ligas
  python update_from_sofascore.py --hoje           # hoje (jogos já encerrados)
  python update_from_sofascore.py --desde 2026-08-01   # carga inicial da temporada
  python update_from_sofascore.py --liga premier --hoje
  python update_from_sofascore.py --find "3. Liga"     # descobrir ID de um torneio
  python update_from_sofascore.py --estado             # mostra acumulado atual

AGENDAMENTO (atualizar todo dia de manhã, pós-rodada)
-----------------------------------------------------
Linux/Mac (crontab -e):
  0 8 * * *  cd /pasta/do/app && python3 update_from_sofascore.py >> log.txt 2>&1
Windows (Agendador de Tarefas): criar tarefa diária às 08:00 executando:
  python update_from_sofascore.py

SAÍDA
-----
  dados_sofascore.js  -> app.html lê automaticamente se estiver na mesma pasta
  sofascore_state.json -> estado interno (não apague; evita contagem duplicada)

AVISO: a API do SofaScore é não-oficial. Use com moderação (o script já
inclui pausas e retentativas). Estatísticas por tempo (gols 1ºT/2ºT) e cartões
dependem da disponibilidade no evento.
"""
import argparse, json, os, re, sys, time, unicodedata, urllib.parse, urllib.request
from datetime import date, datetime, timedelta

BASE = "https://api.sofascore.com/api/v1"
STATE_FILE = " sofascore_state.json".strip()
OUT_FILE = "dados_sofascore.js"
SLEEP = 0.4  # pausa entre requisições

# ---------------------------------------------------------------------------
# CONFIGURAÇÃO DAS LIGAS
# tournament_id: preenchido automaticamente na 1ª execução (ou use --find)
# aliases: nomes do SofaScore que diferem da planilha
# ---------------------------------------------------------------------------
LIGAS = {
    "brasileirao":  {"titulo": "Brasileirão Série A 2026",  "modelo": "simples",
        "aliases": {
            "Clube Athlético Paraneense": "Athletico Paranaense",
            "Clube Atlético Mineiro": "Atlético Mineiro",
            "Esporte Clube Bahia": "Bahia", "Botafogo Futebol e Regatas": "Botafogo",
            "Red Bull Bragantino": "Red Bull Bragantino",
            "Associação Chapecoense de Futebol": "Chapecoense",
            "Sport Club Corinthians Paulista": "Corinthians",
            "Coritiba Football Club": "Coritiba", "Cruzeiro Esporte Clube": "Cruzeiro",
            "Clube de Regatas do Flamengo": "Flamengo",
            "Fluminense Football Club": "Fluminense",
            "Grêmio Foot-Ball Porto Alegrense": "Grêmio",
            "Sport Club Internacional": "Internacional",
            "Mirassol Futebol Clube": "Mirassol",
            "Sociedade Esportiva Palmeiras": "Palmeiras", "Clube do Remo": "Remo",
            "Santos Futebol Clube": "Santos", "São Paulo Futebol Clube": "São Paulo",
            "Clube de Regatas Vasco da Gama": "Vasco da Gama",
            "Esporte Clube Vitória": "Vitória"}},
    "premier":      {"titulo": "Premier League 2026/27", "modelo": "simples", "aliases": {}},
    "bundesliga":   {"titulo": "Bundesliga 2026/27", "modelo": "simples", "aliases": {}},
    "bundesliga2":  {"titulo": "2. Bundesliga 2026/27", "modelo": "simples", "aliases": {}},
    "liga3":        {"titulo": "3. Liga (Alemanha) 2026/27", "modelo": "avancado", "aliases": {}},
    "championship": {"titulo": "EFL Championship (Inglaterra) 2026/27", "modelo": "avancado", "aliases": {}},
    "eredivisie":   {"titulo": "Eredivisie 2026/27", "modelo": "simples", "aliases": {}},
    "eerste":       {"titulo": "Eerste Divisie (Holanda) 2026/27", "modelo": "avancado", "aliases": {}},
}

# nomes de estatísticas aceitos (EN e PT)
STAT_KEYS = {
    "fin":     ["Total shots", "Finalizações", "Total Shots"],
    "fingol":  ["Shots on target", "Finalizações no alvo", "Shots on target (si)"],
    "esc":     ["Corner kicks", "Escanteios"],
    "faltas":  ["Fouls", "Faltas"],
    "ca":      ["Yellow cards", "Cartões amarelos"],
    "cv":      ["Red cards", "Cartões vermelhos"],
}

def norm(s):
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9 ]", "", s).strip()

def get(url, tentativas=3):
    for i in range(tentativas):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Accept": "application/json", "Accept-Language": "en,pt;q=0.8"})
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code in (403, 429, 500, 502, 503) and i < tentativas - 1:
                time.sleep(2 * (i + 1)); continue
            raise
        except Exception:
            if i < tentativas - 1: time.sleep(1.5); continue
            raise
    time.sleep(SLEEP)

def carregar_estado():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, encoding="utf-8") as f: return json.load(f)
    return {"ligas": {}, "eventos": []}

def salvar_estado(st):
    with open(STATE_FILE, "w", encoding="utf-8") as f: json.dump(st, f, ensure_ascii=False, indent=1)

def buscar_torneo(nome):
    dados = get(f"{BASE}/search/all?q={urllib.parse.quote(nome)}&page=0")
    achados = []
    for r in dados.get("results", []):
        ent = r.get("entity", {})
        if r.get("type") in ("uniqueTournament", "tournament") and ent.get("id"):
            achados.append((ent["id"], ent.get("name", "?"), r.get("type")))
    return achados

def resolver_torneo(lid, cfg, st):
    if lid in st["ligas"] and st["ligas"][lid].get("tid"):
        return st["ligas"][lid]["tid"]
    achados = buscar_torneo(cfg["titulo"].split(" 2")[0])
    if not achados:
        raise SystemExit(f"Torneio não encontrado para '{lid}'. Rode: --find \"{cfg['titulo']}\"")
    tid = achados[0][0]
    st["ligas"].setdefault(lid, {})["tid"] = tid
    print(f"  [{lid}] torneio resolvido: id={tid} ({achados[0][1]})")
    time.sleep(SLEEP)
    return tid

def resolver_temporada(lid, tid, st):
    cache = st["ligas"].setdefault(lid, {})
    hoje = date.today()
    chave = f"sid_{hoje.year}"
    if cache.get(chave): return cache[chave]
    dados = get(f"{BASE}/unique-tournament/{tid}/seasons")
    temp = None
    for s in dados.get("seasons", []):
        ano = str(s.get("year", ""))
        if str(hoje.year) in ano or str(hoje.year - 1) in ano:
            temp = s; break
    if temp is None and dados.get("seasons"):
        temp = dados["seasons"][0]
    cache[chave] = temp["id"]
    print(f"  [{lid}] temporada: {temp.get('name')} (season id={temp['id']})")
    time.sleep(SLEEP)
    return temp["id"]

def mapear_nome(nome_ss, times_planilha, aliases):
    if nome_ss in aliases.values(): return nome_ss
    n = norm(nome_ss)
    candidatos = {norm(t): t for t in times_planilha}
    if n in candidatos: return candidatos[n]
    # sobrenomes: "Bayern" casa com "FC Bayern München"
    for nt, original in candidatos.items():
        if n in nt or nt in n: return original
    tok_n = set(n.split())
    melhor, nota = None, 0
    for nt, original in candidatos.items():
        inter = len(tok_n & set(nt.split()))
        if inter > nota: nota, melhor = inter, original
    if nota >= 1: return melhor
    return None

def stats_do_evento(eid):
    dados = get(f"{BASE}/event/{eid}/statistics")
    out = {}
    for periodo in dados.get("statistics", []):
        if periodo.get("period") != "ALL": continue
        for grupo in periodo.get("groups", []):
            for item in grupo.get("statisticsItems", []):
                out[item.get("name", "")] = (item.get("home"), item.get("away"))
    res = {}
    for campo, nomes in STAT_KEYS.items():
        for nm in nomes:
            if nm in out:
                try: res[campo] = (int(out[nm][0] or 0), int(out[nm][1] or 0))
                except (TypeError, ValueError): res[campo] = (0, 0)
                break
    return res

def novo_time(modelo):
    t = dict(j=0, v=0, e=0, d=0, gm=0, gs=0, g1t=0, g2t=0,
             ca=0, cv=0, escf=0, escc=0, faltas=0, fin=0, fingol=0)
    if modelo == "avancado":
        t.update(jc=0, jf=0, vc=0, vf=0, ec=0, ef=0, dc=0, df=0,
                 gmc=0, gmf=0, gsc=0, gsf=0, cs=0, sm=0)
    return t

def acumular(lid, cfg, st, data_alvo):
    lid_st = st["ligas"].setdefault(lid, {"times": {}})
    times = lid_st.setdefault("times", {})
    tid = resolver_torneo(lid, cfg, st)
    sid = resolver_temporada(lid, tid, st)
    url = f"{BASE}/unique-tournament/{tid}/season/{sid}/events/scheduled/{data_alvo}"
    try:
        dados = get(url)
    except Exception as ex:
        print(f"  [{lid}] sem jogos em {data_alvo} ({ex})"); return 0
    eventos = [e for e in dados.get("events", []) if e.get("status", {}).get("type") == "finished"]
    if not eventos:
        print(f"  [{lid}] nenhum jogo finalizado em {data_alvo}"); return 0
    processados, pulados = 0, 0
    for ev in eventos:
        eid = ev["id"]
        if eid in st["eventos"]: pulados += 1; continue
        try:
            stt = stats_do_evento(eid)
        except Exception as ex:
            print(f"  [{lid}] evento {eid}: sem estatísticas, pulado ({ex})"); continue
        nome_h, nome_a = ev["homeTeam"]["name"], ev["awayTeam"]["name"]
        gs_h = ev.get("homeScore", {}) or {}
        gs_a = ev.get("awayScore", {}) or {}
        gh, ga = gs_h.get("current", 0), gs_a.get("current", 0)
        g1_h = gs_h.get("period1"); g1_h = g1_h if g1_h is not None else gh
        g1_a = gs_a.get("period1"); g1_a = g1_a if g1_a is not None else ga
        th = times.setdefault(nome_h, novo_time(cfg["modelo"]))
        ta = times.setdefault(nome_a, novo_time(cfg["modelo"]))
        def soma(t, prefixo, gf, gs, g1):
            t["j"] += 1; t["gm"] += gf; t["gs"] += gs; t["g1t"] += g1; t["g2t"] += gf - g1
            if gf > gs: t["v"] += 1
            elif gf == gs: t["e"] += 1
            else: t["d"] += 1
            if cfg["modelo"] == "avancado":
                casa = prefixo == "c"
                t["jc" if casa else "jf"] += 1
                t["gmc" if casa else "gmf"] += gf
                t["gsc" if casa else "gsf"] += gs
                if gf > gs: t["vc" if casa else "vf"] += 1
                elif gf == gs: t["ec" if casa else "ef"] += 1
                else: t["dc" if casa else "df"] += 1
                if gs == 0: t["cs"] += 1
                if gf == 0: t["sm"] += 1
        soma(th, "c", gh, ga, g1_h)
        soma(ta, "f", ga, gh, g1_a)
        th["ca"] += stt.get("ca", (0, 0))[0];  ta["ca"] += stt.get("ca", (0, 0))[1]
        th["cv"] += stt.get("cv", (0, 0))[0];  ta["cv"] += stt.get("cv", (0, 0))[1]
        th["escf"] += stt.get("esc", (0, 0))[0]; ta["escf"] += stt.get("esc", (0, 0))[1]
        th["escc"] += stt.get("esc", (0, 0))[1]; ta["escc"] += stt.get("esc", (0, 0))[0]
        th["faltas"] += stt.get("faltas", (0, 0))[0]; ta["faltas"] += stt.get("faltas", (0, 0))[1]
        th["fin"] += stt.get("fin", (0, 0))[0];   ta["fin"] += stt.get("fin", (0, 0))[1]
        th["fingol"] += stt.get("fingol", (0, 0))[0]; ta["fingol"] += stt.get("fingol", (0, 0))[1]
        st["eventos"].append(eid)
        processados += 1
        print(f"  [{lid}] {nome_h} {gh}x{ga} {nome_a}  OK")
        time.sleep(SLEEP)
    print(f"  [{lid}] {processados} jogo(s) novos, {pulados} já processado(s)")
    return processados

def gerar_saida(st):
    seed = json.load(open("seed_app.json", encoding="utf-8")) if os.path.exists("seed_app.json") else None
    leagues = []
    for lid, cfg in LIGAS.items():
        times = {}
        if seed:  # herda nomes/ordem da planilha original como base
            for lg in seed["leagues"]:
                if lg["id"] == lid:
                    for t in lg["teams"]:
                        times[t["name"]] = dict(t)
        lid_st = st["ligas"].get(lid, {})
        for nome_ss, vals in lid_st.get("times", {}).items():
            alvo = mapear_nome(nome_ss, list(times.keys()), cfg["aliases"]) or nome_ss
            base = times.setdefault(alvo, {"name": alvo, **novo_time(cfg["modelo"])})
            for k, v in vals.items():
                base[k] = base.get(k, 0) + v
        teams = [dict(t) for t in times.values() if t.get("j", 0) > 0 or not lid_st.get("times")]
        if not teams: teams = [dict(t) for t in times.values()]
        leagues.append({"id": lid, "title": cfg["titulo"], "model": cfg["modelo"], "teams": teams})
    data = {"meta": {"fonte": "SofaScore (atualização automática)",
                     "atualizado_em": datetime.now().strftime("%Y-%m-%d %H:%M"),
                     "temporada": "2026/27"}, "leagues": leagues}
    js = "window.APP_DATA = " + json.dumps(data, ensure_ascii=False) + ";\n"
    with open(OUT_FILE, "w", encoding="utf-8") as f: f.write(js)
    print(f"\n✔ {OUT_FILE} gerado ({len(js)} bytes)")

def main():
    ap = argparse.ArgumentParser(description="Alimenta app.html com dados do SofaScore")
    ap.add_argument("--hoje", action="store_true", help="processa jogos de hoje (encerrados)")
    ap.add_argument("--data", help="data específica AAAA-MM-DD")
    ap.add_argument("--desde", help="carga retroativa: AAAA-MM-DD até hoje (uso único!)")
    ap.add_argument("--liga", choices=list(LIGAS), help="apenas uma liga")
    ap.add_argument("--find", metavar="NOME", help="busca ID de um torneio no SofaScore")
    ap.add_argument("--estado", action="store_true", help="mostra acumulado e sai")
    args = ap.parse_args()

    if args.find:
        for tid, nome, tipo in buscar_torneo(args.find):
            print(f"id={tid:<8} {tipo:<18} {nome}")
        return
    st = carregar_estado()
    if args.estado:
        for lid, cfg in LIGAS.items():
            ts = st["ligas"].get(lid, {}).get("times", {})
            jogos = sum(t.get("j", 0) for t in ts.values()) // 2
            print(f"{lid:13s}: {len(ts)} times, ~{jogos} jogos processados")
        print(f"eventos no histórico: {len(st['eventos'])}")
        return

    if args.desde:
        datas, d = [], datetime.strptime(args.desde, "%Y-%m-%d").date()
        while d <= date.today(): datas.append(d.isoformat()); d += timedelta(days=1)
        print(f"Carga retroativa de {datas[0]} até {datas[-1]} ({len(datas)} dias)")
    else:
        alvo = date.today() if args.hoje else (datetime.strptime(args.data, "%Y-%m-%d").date()
                                               if args.data else date.today() - timedelta(days=1))
        datas = [alvo.isoformat()]

    lids = [args.liga] if args.liga else list(LIGAS)
    total = 0
    for lid in lids:
        cfg = LIGAS[lid]
        print(f"\n=== {cfg['titulo']} ===")
        for dt in datas:
            try:
                total += acumular(lid, cfg, st, dt)
            except SystemExit: raise
            except Exception as ex:
                print(f"  [{lid}] ERRO em {dt}: {ex}")
            salvar_estado(st)  # checkpoint por etapa
    gerar_saida(st)
    print(f"\nTotal de jogos novos processados: {total}")

if __name__ == "__main__":
    main()
